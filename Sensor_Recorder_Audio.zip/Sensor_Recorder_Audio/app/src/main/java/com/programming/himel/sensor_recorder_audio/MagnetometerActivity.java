package com.programming.himel.sensor_recorder_audio;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MagnetometerActivity extends AppCompatActivity implements SensorEventListener{
    private Sensor mMagnetometer;
    private SensorManager manager;
    TextView xMagValue,yMagValue,zMagValue;

    private static final String TAG = "GyroscopeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_magnetometer);


        xMagValue = findViewById(R.id.xMagValue);
        yMagValue = findViewById(R.id.yMagValue);
        zMagValue = findViewById(R.id.zMagValue);

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        mMagnetometer = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        if (mMagnetometer !=null){
            manager.registerListener(MagnetometerActivity.this,mMagnetometer
                    ,SensorManager.SENSOR_DELAY_NORMAL);
            Log.e(TAG,"onCreate :");

            Toast.makeText(this, "Register Gyro Sensor", Toast.LENGTH_SHORT).show();

        }
        else {
            xMagValue.setText("Gyro Sensor Not Supported");
            yMagValue.setText("Gyro Sensor Not Supported");
            zMagValue.setText("Gyro Sensor Not Supported");
        }


    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;

        if (sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){

            xMagValue.setText("xMagneticValue : "+sensorEvent.values[0]);
            yMagValue.setText("yMagneticValue : "+sensorEvent.values[1]);
            zMagValue.setText("zMagneticValue : "+sensorEvent.values[2]);


        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
