package com.programming.himel.sensor_recorder_audio;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class PressureActivity extends AppCompatActivity implements SensorEventListener {
    private Sensor mPressure;
    private SensorManager manager;
    TextView xPreValue, yPreValue, zPreValue;

    private static final String TAG = "PressureActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pressure);


        xPreValue = findViewById(R.id.xPreValue);
        yPreValue = findViewById(R.id.yPreValue);
        zPreValue = findViewById(R.id.zPreValue);

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        mPressure = manager.getDefaultSensor(Sensor.TYPE_PRESSURE);

        if (mPressure !=null){
            manager.registerListener(PressureActivity.this, mPressure
                    ,SensorManager.SENSOR_DELAY_NORMAL);
            Log.e(TAG,"onCreate :");

            Toast.makeText(this, "Register Pressure Sensor", Toast.LENGTH_SHORT).show();

        }
        else {
            xPreValue.setText("Pressure Sensor Not Supported");
            yPreValue.setText("Pressure Sensor Not Supported");
            zPreValue.setText("Pressure Sensor Not Supported");
        }


    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;

        if (sensor.getType() == Sensor.TYPE_PRESSURE){

            xPreValue.setText("xPressureValue : "+sensorEvent.values[0]);
            yPreValue.setText("yPressureValue : "+sensorEvent.values[1]);
            zPreValue.setText("zPressureValue : "+sensorEvent.values[2]);


        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}

