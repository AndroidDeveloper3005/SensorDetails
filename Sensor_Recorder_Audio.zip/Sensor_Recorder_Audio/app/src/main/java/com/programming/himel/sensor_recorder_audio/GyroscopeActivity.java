package com.programming.himel.sensor_recorder_audio;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class GyroscopeActivity extends AppCompatActivity implements SensorEventListener{
    private Sensor mGyroscope;
    private SensorManager manager;
    TextView xGyroValue,yGyroValue,zGyroValue;

    private static final String TAG = "GyroscopeActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gyroscope);

        xGyroValue = findViewById(R.id.xGyroValue);
        yGyroValue = findViewById(R.id.yGyroValue);
        zGyroValue = findViewById(R.id.zGyroValue);

        manager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        mGyroscope = manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        if (mGyroscope !=null){
            manager.registerListener(GyroscopeActivity.this,mGyroscope
                    ,SensorManager.SENSOR_DELAY_NORMAL);
            Log.e(TAG,"onCreate :");

            Toast.makeText(this, "Register Gyro Sensor", Toast.LENGTH_SHORT).show();

        }
        else {
            xGyroValue.setText("Gyro Sensor Not Supported");
            yGyroValue.setText("Gyro Sensor Not Supported");
            zGyroValue.setText("Gyro Sensor Not Supported");
        }



    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        Sensor sensor = sensorEvent.sensor;

        if (sensor.getType() == Sensor.TYPE_GYROSCOPE){

            xGyroValue.setText("xGyroscopeValue : "+sensorEvent.values[0]);
            yGyroValue.setText("yGyroscopeValue : "+sensorEvent.values[1]);
            zGyroValue.setText("zGyroscopeValue : "+sensorEvent.values[2]);


        }


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
